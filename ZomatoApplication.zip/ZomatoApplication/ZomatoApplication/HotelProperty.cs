﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotalListPage
{
    public class HotelProperty
    {

        public int HotelID
        {
            get; set;
        }

        public string HotelName
        {

            get; set;

        }
        public int Phone
        {
            get;
            set;
        }

        public string Address
        {
            get;
            set;
        }

        public int Price
        {
            get; set;

        }
    }
}
